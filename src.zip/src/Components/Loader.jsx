import {Spinner,Bouncer,Flipper} from './LandingPage.style'
const Loader = () =>{
    return (<Flipper>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
            </Flipper>)
}

export default Loader;